# 🗺️ Plan de Migration Documentation - Render Signal Server

**Objectif** : Transformer la documentation technique actuelle (très descriptive et dispersée) en une base de connaissances narrative selon la méthode **SKILL.md**.
**Philosophie** : Passer de "Comment configurer la variable X" à "Comment déployer un serveur de signal résilient".

**Référence de Style** : `.windsurf/skills/documentation/SKILL.md` (Assurez-vous que ce fichier est présent à la racine).

---

## 🛠 Phase 0 : Initialisation

- [ ] **Création de l'espace de travail**
  - Créer le répertoire cible : `mkdir -p docs/v2`
  - S'assurer que le fichier `.windsurf/skills/documentation/SKILL.md` est chargé dans le contexte de l'IA.

---

## 🏗 Phase 1 : Architecture & Structure Cible

L'agent doit créer l'arborescence dans `docs/v2` pour refléter l'architecture "Service-Oriented" du projet, et non plus une liste de fonctionnalités en vrac.

- `core/` : La vision globale (Architecture Services, le "Pourquoi" du projet).
- `ingestion/` : Tout ce qui concerne l'entrée des données (Gmail Push, legacy IMAP).
- `processing/` : Le cœur du réacteur (Orchestrator, Routing Rules, R2 Offload).
- `access/` : Sécurité et Entrées (Magic Links, Dashboard, Auth).
- `ops/` : Déploiement Render, Configuration Redis, Monitoring.

**Commande pour l'agent :**
> "Analyse la structure cible ci-dessus et génère les commandes `mkdir -p` pour créer cette arborescence dans `docs/v2`."

---

## ✍️ Phase 2 : Migration & Réécriture (Fichier par Fichier)

Pour chaque fichier, l'agent doit lire la source, **filtrer le bruit** (anciens logs de refactoring), et réécrire en suivant le prompt ci-dessous.

### 📜 Le Prompt de Migration (À copier/coller à l'agent)

```markdown
@SKILL.md
Agis comme un Lead Developer rédigeant pour ses pairs.

**Tâche** : Réécrire le contenu du fichier source pour la nouvelle destination `docs/v2`.
**Source** : [OUVRIR LE FICHIER SOURCE]
**Destination** : [CHEMIN DANS docs/v2/...]

**Contraintes Critiques :**
1. **Zéro Perte Technique** : Conserve STRICTEMENT les noms de variables d'env (`FLASK_SECRET_KEY`, `R2_FETCH_TOKEN`), les endpoints API (`/api/ingress/gmail`) et les commandes CLI.
2. **Style SKILL.md** :
   - Commencer par le **Problème** (ex: "Les serveurs Render ont peu de bande passante").
   - Enchaîner sur la **Solution** (ex: "On utilise R2 pour offloader les gros fichiers").
   - Utiliser des blocs **❌ Avant / ✅ Après** pour expliquer les choix (ex: IMAP vs Gmail Push).
3. **Nettoyage** :
   - Ne pas migrer les "Logs de refactoring" ou les "Statuts 2025". Ce sont des archives.
   - Intégrer les "Audits" directement dans la documentation comme "Limitations connues" ou "Points d'attention".

**Action** : Génère le contenu Markdown complet.
```

### 📋 Liste de Contrôle des Fichiers Clés

#### 1. Core (Les Fondations)
- [ ] `docs/architecture/overview.md` + `README.md` → `docs/v2/core/architecture.md`
  *Angle : Expliquer l'architecture "Service-Oriented" (Singleton) et le concept de "Store-as-Source-of-Truth" (Redis).*
- [ ] `configuration/configuration.md` → `docs/v2/core/configuration-reference.md`
  *Angle : Ne pas juste lister. Grouper par "Services" (Config du Poller, Config R2, Config Auth).*

#### 2. Ingestion (Entrée des données)
- [ ] `features/gmail_push_ingress.md` + `features/gmail_push_patterns.md` → `docs/v2/ingestion/gmail-push.md`
  *Angle : "Pourquoi on a tué le Polling IMAP". Expliquer le flux Apps Script -> API.*
- [ ] `features/email_polling_legacy.md` → `docs/v2/ingestion/legacy-imap.md`
  *Angle : Garder pour référence historique, mais marquer clairement comme déprécié.*

#### 3. Processing (Traitement)
- [ ] `features/routing_rules_engine.md` + `features/routing_rules_lock.md` → `docs/v2/processing/routing-engine.md`
  *Angle : Expliquer comment le moteur dynamique remplace le code "hardcodé". Mentionner le verrouillage UI.*
- [ ] `integrations/r2_offload.md` + `features/r2_transfer_service.md` → `docs/v2/processing/file-offload.md`
  *Angle : Le problème de coût de bande passante Render et la solution Worker Cloudflare.*
- [ ] `features/webhooks.md` + `features/webhook_logs_redis.md` → `docs/v2/processing/webhooks-outbound.md`
  *Angle : La fiabilité d'envoi et la persistance des logs dans Redis.*

#### 4. Access (Interface & Sécurité)
- [ ] `features/magic_link_auth.md` → `docs/v2/access/authentication.md`
  *Angle : Sécurité sans mot de passe. HMAC signing.*
- [ ] `features/frontend_dashboard_features.md` + `features/ui.md` → `docs/v2/access/dashboard-ui.md`
  *Angle : Architecture modulaire ES6 du front. UX "Mobile First".*

#### 5. Ops (Opérations)
- [ ] `operations/deploiement.md` + `operations/multi-container-deployment.md` → `docs/v2/ops/deployment.md`
  *Angle : Docker GHCR pipeline et le challenge du multi-conteneur (Verrou Redis).*
- [ ] `operations/operational-guide.md` + `quality/performance.md` → `docs/v2/ops/monitoring.md`
  *Angle : Comment savoir si le service est vivant ? (Healthchecks, Logs).*
- [ ] `operations/depannage.md` → `docs/v2/ops/troubleshooting.md`
  *Angle : Guide de survie.*

---

## 🔗 Phase 3 : Unification

- [ ] **Générer le README racine** : `docs/v2/README.md`
  *Prompt : "Crée un README qui sert de carte d'accès. Présente le projet comme un 'Middleware d'ingestion Email haute performance'. Guide le lecteur vers les dossiers `ingestion`, `processing`, `ops`."*

- [ ] **Vérification croisée** :
  *Prompt : "Vérifie que le concept de 'Absence Globale' (Global Absence) est bien documenté dans `webhooks-outbound.md` et mentionné dans `dashboard-ui.md`."*

---

## 🚀 Phase 4 : Bascule

Une fois la nouvelle documentation validée :

```bash
# 1. Archiver l'ancien dossier docs (sauf images si besoin)
mkdir docs_archive_legacy
mv docs/* docs_archive_legacy/ 2>/dev/null

# 2. Promouvoir la v2
mv docs_archive_legacy/v2/* docs/
rm -rf docs_archive_legacy/v2

# 3. Nettoyer (Optionnel)
# rm -rf docs_archive_legacy
```